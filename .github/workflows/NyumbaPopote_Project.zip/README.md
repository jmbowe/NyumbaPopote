NyumbaPopote Project – Combined Package

Includes:
- Backend (API + logic)
- Web App (React)
- Mobile App (React Native)
- Scripts (Launch scripts)
- Assets (Logos, images)

Each folder has README.md and placeholder.txt files.
