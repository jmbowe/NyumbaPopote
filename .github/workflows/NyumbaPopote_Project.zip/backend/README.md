NyumbaPopote Backend – Handles subscriptions, houses, payments, promotions, maps, and notifications.
