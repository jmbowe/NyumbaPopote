NyumbaPopote Web App – React frontend with catalog, dashboard, subscriptions, payments, and multi-language (EN/SW).
