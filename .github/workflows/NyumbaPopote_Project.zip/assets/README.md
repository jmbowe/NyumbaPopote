Logos and placeholder images for NyumbaPopote.
