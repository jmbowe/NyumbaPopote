Scripts for launching web and mobile apps on Windows/Linux.
