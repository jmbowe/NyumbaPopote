NyumbaPopote Mobile App – React Native frontend with catalog, dashboard, payments, and multi-language (EN/SW).
